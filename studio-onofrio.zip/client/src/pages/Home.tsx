/**
 * Design reminder — Archivio Clinico Italiano:
 * homepage come sequenza editoriale e non come template: informazioni chiare, trame tattili
 * non figurative come fallback e CTA telefoniche esplicite in ogni snodo importante.
 */
import { ArrowRight, Check, MapPin, Phone, Stethoscope } from "lucide-react";
import { Link } from "wouter";
import {
  business,
  services,
  specializationAreas,
  visualFallbacks,
} from "@/data/business";
import {
  ContactActions,
  Eyebrow,
  Gallery,
  HoursTable,
  PageLayout,
  RatingBadge,
  SectionHeading,
} from "@/components/SiteShared";

export default function Home() {
  return (
    <PageLayout>
      <section className="home-hero">
        <div className="home-hero__content">
          <div className="home-hero__copy">
            <div className="hero-kicker">
              <span aria-hidden="true" />
              <Eyebrow>Faicchio · Benevento</Eyebrow>
            </div>
            <h1>
              Medico Chirurgo
              <em> Colonproctologo</em>
            </h1>
            <p className="home-hero__name">{business.doctorName}</p>
            <p className="home-hero__lead">
              Chirurgia generale e colonproctologia con un approccio professionale, attento e orientato alla persona.
            </p>
            <ContactActions />
            <RatingBadge />
          </div>
          <div className="home-hero__visual">
            <img
              src={visualFallbacks.hero}
              alt="Texture astratta decorativa in avorio e blu, usata in attesa di una fotografia autorizzata"
              fetchPriority="high"
            />
          </div>
        </div>
        <div className="home-hero__lower" aria-label="Informazioni principali">
          <span><MapPin size={17} aria-hidden="true" /> {business.addressShort}</span>
          <span><Phone size={17} aria-hidden="true" /> {business.phoneDisplay}</span>
          <span><Stethoscope size={17} aria-hidden="true" /> {business.descriptor}</span>
        </div>
      </section>

      <section className="intro-section section-space">
        <div className="intro-section__rail"><span>02</span><i /></div>
        <div className="intro-section__content">
          <SectionHeading
            eyebrow="Un approccio chiaro"
            title="Competenza specialistica, attenzione alla persona"
            lead="Ogni richiesta merita ascolto, chiarezza e un orientamento specialistico adeguato. Per informazioni o per fissare un appuntamento, è possibile contattare direttamente lo studio."
          />
          <div className="intro-section__details">
            <p>
              Il Dott. Luciano Onofrio è presentato come <strong>Chirurgo Generale e Proctologo</strong>. Le informazioni riportate in questo sito sono essenziali e vengono mantenute aggiornabili per favorire un contatto semplice e consapevole.
            </p>
            <Link href="/dottore" className="text-link">Conoscere il Dott. Luciano Onofrio <ArrowRight size={16} /></Link>
          </div>
        </div>
      </section>

      <section className="areas-section section-space" id="specializzazioni">
        <div className="areas-section__top">
          <SectionHeading
            index="03"
            eyebrow="Ambiti specialistici"
            title="Un percorso ordinato, dall’ascolto alla valutazione"
            lead="Gli ambiti riportati sono presentati a scopo informativo e saranno confermati e aggiornati dal titolare dello studio."
          />
          <Link href="/specializzazioni" className="text-link">Vedi tutti gli ambiti <ArrowRight size={16} /></Link>
        </div>
        <ul className="areas-list">
          {specializationAreas.slice(0, 6).map((area, index) => (
            <li key={area}>
              <span>0{index + 1}</span>
              <strong>{area}</strong>
              <Check size={17} aria-hidden="true" />
            </li>
          ))}
        </ul>
      </section>

      <section className="services-section section-space" id="prestazioni">
        <div className="services-section__rail"><span>04</span><i /></div>
        <div className="services-section__content">
          <SectionHeading
            eyebrow="Prestazioni"
            title="Valutazioni specialistiche, spiegate con semplicità"
            lead="Le prestazioni sono descritte in modo informativo, senza sostituire il confronto diretto con lo specialista."
          />
          <div className="services-list">
            {services.map((service, index) => (
              <article key={service.title} className="service-item">
                <span className="service-item__number">0{index + 1}</span>
                <div>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </div>
                <a href={business.phoneHref} aria-label={`Contatta lo studio per ${service.title}`}>
                  <ArrowRight size={19} />
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="doctor-preview section-space">
        <div className="doctor-preview__image">
          <img src={visualFallbacks.notes} alt="Texture editoriale astratta decorativa" loading="lazy" />
          <div className="doctor-preview__image-note">Profilo professionale<br />in aggiornamento</div>
        </div>
        <div className="doctor-preview__copy">
          <SectionHeading
            index="05"
            eyebrow="Il Dottore"
            title="Dott. Luciano Onofrio"
            lead={business.descriptor}
          />
          <p>
            Il sito è predisposto per presentare ulteriori informazioni professionali esclusivamente quando saranno verificate. La fotografia del medico sarà inserita solo dopo la disponibilità di un’immagine originale autorizzata.
          </p>
          <Link href="/dottore" className="text-link">Vai al profilo <ArrowRight size={16} /></Link>
        </div>
      </section>

      <section className="studio-section section-space" id="studio">
        <div className="studio-section__top">
          <SectionHeading
            index="06"
            eyebrow="Lo studio"
            title="Indicazioni semplici per raggiungere lo studio"
            lead="La sede e gli orari sono sempre disponibili in questa pagina, insieme al collegamento diretto alle indicazioni stradali."
          />
          <div className="address-card">
            <MapPin size={22} aria-hidden="true" />
            <p>{business.address}</p>
            <a href={business.directionsUrl} target="_blank" rel="noreferrer">Apri le indicazioni <ArrowRight size={16} /></a>
          </div>
        </div>
        <div className="studio-section__grid">
          <HoursTable />
          <Gallery compact />
        </div>
      </section>

      <section className="reviews-section section-space" id="recensioni">
        <div className="reviews-section__rating">
          <Eyebrow>La fiducia dei pazienti</Eyebrow>
          <div className="reviews-section__score">{business.rating}<small>/ 5</small></div>
          <div className="reviews-section__stars" aria-label={`Valutazione ${business.rating} su 5`}>
            ★★★★★
          </div>
          <p>{business.reviewCount} recensioni Google</p>
        </div>
        <div className="reviews-section__copy">
          <h2>Un riferimento diretto alle recensioni pubblicate.</h2>
          <p>
            Per correttezza, questo sito non trascrive né ricrea testimonianze. È possibile consultare le recensioni direttamente nella scheda Google dell’attività.
          </p>
          <a className="button button--primary" href={business.mapsListingUrl} target="_blank" rel="noreferrer">
            Leggi le recensioni su Google <ArrowRight size={17} />
          </a>
        </div>
      </section>

      <section className="final-contact">
        <div className="final-contact__texture" style={{ backgroundImage: `url(${visualFallbacks.navigation})` }} aria-hidden="true" />
        <div className="final-contact__content">
          <Eyebrow>Contatti</Eyebrow>
          <h2>Prenota una visita</h2>
          <p>Per informazioni o per fissare un appuntamento, contatta direttamente lo studio.</p>
          <a className="final-contact__phone" href={business.phoneHref}>{business.phoneDisplay}</a>
          <ContactActions variant="light" />
        </div>
      </section>
    </PageLayout>
  );
}

