/**
 * Design reminder — Archivio Clinico Italiano:
 * pagine interne come fascicoli ordinati: un’intestazione di consultazione, informazione
 * verificabile, margini ampi e inviti al contatto senza promesse cliniche o marketing aggressivo.
 */
import { ArrowRight, Check, ExternalLink, MapPin, Phone, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { business, services, specializationAreas, visualFallbacks } from "@/data/business";
import {
  ContactActions,
  Eyebrow,
  Gallery,
  HoursTable,
  PageHero,
  PageLayout,
  RatingBadge,
  SectionHeading,
} from "@/components/SiteShared";

export function DoctorPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Il Dottore" title="Dott. Luciano Onofrio" lead={business.descriptor} caption="Profilo professionale" />
      <section className="profile-page section-space">
        <div className="profile-page__visual">
          <img src={visualFallbacks.notes} alt="Texture astratta decorativa in attesa di una fotografia professionale autorizzata" />
          <p>La fotografia professionale sarà inserita esclusivamente con un’immagine originale e autorizzata.</p>
        </div>
        <div className="profile-page__copy">
          <Eyebrow>Profilo</Eyebrow>
          <h2>Informazioni essenziali, senza aggiunte non verificate.</h2>
          <p>
            Il Dott. Luciano Onofrio è presentato sul sito come Chirurgo Generale e Proctologo. Per scelta di accuratezza, titoli, formazione, esperienze professionali, pubblicazioni e collaborazioni non sono riportati finché non saranno resi disponibili e confermati dal titolare.
          </p>
          <div className="profile-page__notice">
            <ShieldCheck size={20} aria-hidden="true" />
            <p>La precisione dei dati viene prima della quantità di informazioni pubblicate.</p>
          </div>
          <ContactActions />
        </div>
      </section>
      <section className="profile-contact-band">
        <div><span>01</span><Eyebrow>Contatto diretto</Eyebrow></div>
        <p>Per informazioni e appuntamenti, è possibile rivolgersi direttamente allo studio.</p>
        <a href={business.phoneHref}>{business.phoneDisplay} <ArrowRight size={17} /></a>
      </section>
    </PageLayout>
  );
}

export function SpecializationsPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Specializzazioni" title="Ambiti di competenza" lead="Una panoramica informativa delle aree indicate per lo studio." caption="Informazioni da confermare e aggiornare" />
      <section className="specializations-page section-space">
        <SectionHeading eyebrow="Orientamento specialistico" title="Informazioni chiare per iniziare il confronto" lead="Gli ambiti seguenti sono presentati come riferimento informativo e non come promessa di trattamento o risultato." />
        <div className="specializations-page__list">
          {specializationAreas.map((area, index) => (
            <article key={area}>
              <span>0{index + 1}</span>
              <h3>{area}</h3>
              <Check size={20} aria-hidden="true" />
            </article>
          ))}
        </div>
      </section>
      <section className="services-page section-space">
        <SectionHeading eyebrow="Prestazioni" title="Valutazioni e percorsi da discutere con lo specialista" />
        <div className="services-list services-list--full">
          {services.map((service, index) => (
            <article key={service.title} className="service-item">
              <span className="service-item__number">0{index + 1}</span>
              <div><h3>{service.title}</h3><p>{service.description}</p></div>
              <a href={business.phoneHref} aria-label={`Contatta lo studio per ${service.title}`}><Phone size={19} /></a>
            </article>
          ))}
        </div>
      </section>
      <section className="contact-inset"><div><Eyebrow>Informazioni</Eyebrow><h2>Vuole fissare un appuntamento?</h2></div><ContactActions /></section>
    </PageLayout>
  );
}

export function StudioPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Lo studio" title="Raggiungere lo studio" lead="Indirizzo, orari e indicazioni in un unico punto." caption="Faicchio · Benevento" />
      <section className="studio-page section-space">
        <div className="studio-page__address">
          <Eyebrow>Sede</Eyebrow>
          <MapPin size={27} aria-hidden="true" />
          <h2>{business.address}</h2>
          <p>Per raggiungere la sede, utilizzare il collegamento diretto alle indicazioni stradali.</p>
          <a className="button button--primary" href={business.directionsUrl} target="_blank" rel="noreferrer">Come arrivare <ExternalLink size={17} /></a>
          <a className="text-link" href={business.mapsListingUrl} target="_blank" rel="noreferrer">Apri la scheda Google Maps <ArrowRight size={16} /></a>
        </div>
        <HoursTable highlighted />
      </section>
      <section className="studio-gallery section-space">
        <SectionHeading eyebrow="Ambienti" title="Galleria dello studio" lead="Le fotografie saranno inserite solo dopo verifica della pertinenza e dell’autorizzazione d’uso." />
        <Gallery />
      </section>
      <section className="studio-page__note"><img src={visualFallbacks.navigation} alt="Trama astratta decorativa" loading="lazy" /><div><Eyebrow>Nota sull’indirizzo</Eyebrow><p>È pubblicato l’indirizzo di riferimento associato alla scheda Google Maps indicata. Un eventuale indirizzo alternativo sarà mostrato solo dopo conferma del titolare.</p></div></section>
    </PageLayout>
  );
}

export function GalleryPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Gallery" title="Gli spazi dello studio" lead="Una raccolta predisposta per fotografie originali e pertinenti dell’attività." caption="Immagini autorizzate" />
      <section className="gallery-page section-space"><Gallery /><div className="gallery-page__contact"><p>Per informazioni sulla sede o per indicazioni, contatti direttamente lo studio.</p><ContactActions /></div></section>
    </PageLayout>
  );
}

export function ContactsPage() {
  return (
    <PageLayout>
      <PageHero eyebrow="Contatti" title="Prenota una visita" lead="Per informazioni o per fissare un appuntamento, contatta direttamente lo studio." caption="Contatto diretto" />
      <section className="contacts-page section-space">
        <div className="contacts-page__primary">
          <Eyebrow>Dott. Luciano Onofrio</Eyebrow>
          <h2>{business.descriptor}</h2>
          <a className="contacts-page__phone" href={business.phoneHref}><Phone size={23} aria-hidden="true" /> {business.phoneDisplay}</a>
          <p>Il sito non richiede l’invio di sintomi, diagnosi, referti, fotografie mediche o altre informazioni sanitarie.</p>
          <ContactActions />
        </div>
        <div className="contacts-page__side">
          <div className="contacts-detail"><MapPin size={21} /><div><Eyebrow>Sede</Eyebrow><p>{business.address}</p><a href={business.directionsUrl} target="_blank" rel="noreferrer">Indicazioni stradali <ArrowRight size={15} /></a></div></div>
          <RatingBadge />
        </div>
      </section>
      <section className="contacts-hours section-space"><HoursTable highlighted /><div><SectionHeading eyebrow="Lo studio" title="Tutte le informazioni essenziali in un unico contatto." lead="Per consultare la posizione aggiornata e le recensioni, è possibile aprire direttamente la scheda Google Maps." /><a className="button button--secondary" href={business.mapsListingUrl} target="_blank" rel="noreferrer">Apri Google Maps <ExternalLink size={17} /></a></div></section>
    </PageLayout>
  );
}

function PolicyLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return <PageLayout><PageHero eyebrow="Informative" title={title} lead="Pagina predisposta per la revisione e il completamento prima della pubblicazione." caption="Bozza da verificare" /><article className="policy-page section-space">{children}</article></PageLayout>;
}

export function PrivacyPage() {
  return (
    <PolicyLayout title="Privacy Policy">
      <div className="policy-page__alert"><ShieldCheck size={21} /><p><strong>Stato della pagina:</strong> struttura informativa da completare e validare dal titolare del trattamento prima della pubblicazione online.</p></div>
      <h2>Informazioni sul trattamento dei dati personali</h2>
      <p>La presente pagina deve essere completata con i dati del titolare del trattamento, i recapiti per l’esercizio dei diritti, gli effettivi fornitori tecnici e gli eventuali tempi di conservazione applicabili al sito pubblicato.</p>
      <h3>Funzionalità della versione presentata</h3>
      <p>La versione realizzata non contiene moduli di contatto, sistemi di prenotazione, newsletter, pixel pubblicitari, widget social, mappe incorporate o strumenti di analisi attivati dal frontend. Le azioni “Chiama” aprono il telefono dell’utente; i collegamenti a Google Maps portano a un sito esterno, soggetto alle relative informative.</p>
      <h3>Dati sanitari</h3>
      <p>Il sito è progettato per non raccogliere informazioni sanitarie. Per informazioni o appuntamenti è disponibile esclusivamente il contatto telefonico diretto con lo studio.</p>
      <h3>Elementi da confermare prima del rilascio</h3>
      <ul><li>Identità e recapiti del titolare del trattamento.</li><li>Provider di hosting e relativa documentazione dei log tecnici.</li><li>Eventuali responsabili del trattamento e trasferimenti di dati.</li><li>Canale effettivo per l’esercizio dei diritti degli interessati.</li></ul>
      <p>Qualora vengano aggiunti in futuro form, analytics, font esterni, mappe incorporate, cookie non tecnici o altri servizi di terze parti, l’informativa dovrà essere aggiornata prima della loro attivazione.</p>
    </PolicyLayout>
  );
}

export function CookiePolicyPage() {
  return (
    <PolicyLayout title="Cookie Policy">
      <div className="policy-page__alert"><ShieldCheck size={21} /><p><strong>Stato della pagina:</strong> bozza strutturale da verificare in base ai servizi effettivamente presenti al momento della pubblicazione.</p></div>
      <h2>Uso di cookie e tecnologie analoghe</h2>
      <p>La versione frontend realizzata non attiva intenzionalmente cookie di profilazione, pixel pubblicitari, widget social o sistemi di analisi lato client. I link esterni, inclusi quelli a Google Maps, aprono pagine soggette alle rispettive politiche e impostazioni dell’utente.</p>
      <h3>Verifica necessaria prima della pubblicazione</h3>
      <p>Il titolare dovrà verificare con il provider di hosting l’eventuale presenza di cookie o tecnologie tecniche indispensabili e integrare in questa pagina l’informativa appropriata. L’introduzione futura di servizi non tecnici richiederà la gestione del consenso secondo la normativa applicabile prima dell’attivazione.</p>
      <h3>Gestione delle preferenze</h3>
      <p>Se saranno implementate tecnologie che richiedono consenso, verrà aggiunto un pannello di preferenze accessibile e una descrizione aggiornata delle categorie, delle finalità e dei fornitori coinvolti.</p>
    </PolicyLayout>
  );
}

