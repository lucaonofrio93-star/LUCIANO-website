/**
 * Design reminder — Archivio Clinico Italiano:
 * il layout globale mantiene una navigazione trasparente e accessibile in tutte le pagine,
 * così che la persona possa sempre tornare a contatti, indicazioni e appuntamento telefonico.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import {
  ContactsPage,
  CookiePolicyPage,
  DoctorPage,
  GalleryPage,
  PrivacyPage,
  SpecializationsPage,
  StudioPage,
} from "./pages/InfoPages";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dottore" component={DoctorPage} />
      <Route path="/specializzazioni" component={SpecializationsPage} />
      <Route path="/studio" component={StudioPage} />
      <Route path="/gallery" component={GalleryPage} />
      <Route path="/contatti" component={ContactsPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/cookie-policy" component={CookiePolicyPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

