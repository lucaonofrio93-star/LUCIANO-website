/**
 * Design reminder — Archivio Clinico Italiano:
 * componenti sottili, leggibili e funzionali. Il blu inchiostro ordina le informazioni;
 * ogni CTA esplicita l’azione e l’eventuale asset fotografico è gestito dalla configurazione.
 */
import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  ArrowRight,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock3,
  ExternalLink,
  MapPin,
  Menu,
  Phone,
  Star,
  X,
} from "lucide-react";
import {
  business,
  galleryItems,
  navigation,
  openingHours,
  type GalleryItem,
} from "@/data/business";

export function Eyebrow({ children }: { children: React.ReactNode }) {
  return <p className="eyebrow">{children}</p>;
}

export function SectionHeading({
  index,
  eyebrow,
  title,
  lead,
  className = "",
}: {
  index?: string;
  eyebrow: string;
  title: string;
  lead?: string;
  className?: string;
}) {
  return (
    <header className={`section-heading ${className}`}>
      <div className="section-heading__meta">
        {index && <span className="section-heading__index">{index}</span>}
        <Eyebrow>{eyebrow}</Eyebrow>
      </div>
      <h2>{title}</h2>
      {lead && <p className="section-heading__lead">{lead}</p>}
    </header>
  );
}

export function RatingBadge({ compact = false }: { compact?: boolean }) {
  return (
    <a
      className={`rating-badge ${compact ? "rating-badge--compact" : ""}`}
      href={business.mapsListingUrl}
      target="_blank"
      rel="noreferrer"
      aria-label={`Valutazione ${business.rating} su Google, ${business.reviewCount} recensioni. Apri la scheda Google Maps.`}
    >
      <span className="rating-badge__stars" aria-hidden="true">
        {[0, 1, 2, 3, 4].map((star) => (
          <Star key={star} size={compact ? 13 : 15} fill="currentColor" />
        ))}
      </span>
      <span>
        <strong>{business.rating} su Google</strong>
        <small>{business.reviewCount} recensioni</small>
      </span>
      {!compact && <ExternalLink size={15} aria-hidden="true" />}
    </a>
  );
}

export function ContactActions({
  variant = "default",
  showDirections = true,
}: {
  variant?: "default" | "light";
  showDirections?: boolean;
}) {
  return (
    <div className={`contact-actions contact-actions--${variant}`}>
      <a className="button button--primary" href={business.phoneHref}>
        <Phone size={18} aria-hidden="true" />
        <span>Prenota una visita</span>
      </a>
      {showDirections && (
        <a
          className="button button--secondary"
          href={business.directionsUrl}
          target="_blank"
          rel="noreferrer"
        >
          <MapPin size={18} aria-hidden="true" />
          <span>Come arrivare</span>
        </a>
      )}
    </div>
  );
}

export function HoursTable({ highlighted = false }: { highlighted?: boolean }) {
  return (
    <section
      className={`hours-card ${highlighted ? "hours-card--highlighted" : ""}`}
      aria-labelledby="orari-title"
    >
      <div className="hours-card__header">
        <Clock3 size={20} aria-hidden="true" />
        <div>
          <Eyebrow>Informazioni pratiche</Eyebrow>
          <h3 id="orari-title">Orari di ricevimento</h3>
        </div>
      </div>
      <dl className="hours-list">
        {openingHours.map(({ day, hours, closed }) => (
          <div className="hours-list__row" key={day}>
            <dt>{day}</dt>
            <dd className={closed ? "is-closed" : ""}>{hours}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

function BrandBlock({ light = false }: { light?: boolean }) {
  return (
    <span className={`brand-block ${light ? "brand-block--light" : ""}`}>
      <span className="brand-block__rule" aria-hidden="true" />
      <span className="brand-block__copy">
        <strong>Luciano Onofrio</strong>
        <small>Medico Chirurgo Colonproctologo</small>
      </span>
    </span>
  );
}

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!menuOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [menuOpen]);

  return (
    <>
      <header className="site-header">
        <div className="site-header__inner">
          <Link href="/" aria-label="Torna alla Home">
            <BrandBlock />
          </Link>
          <nav className="desktop-nav" aria-label="Navigazione principale">
            {navigation.map((item) => (
              <Link key={item.label} href={item.href}>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="site-header__actions">
            <a className="header-call" href={business.phoneHref}>
              <Phone size={15} aria-hidden="true" />
              <span>Chiama</span>
            </a>
            <a className="button button--header" href={business.phoneHref}>
              Prenota una visita
            </a>
            <button
              type="button"
              className="menu-trigger"
              onClick={() => setMenuOpen(true)}
              aria-label="Apri il menu di navigazione"
              aria-expanded={menuOpen}
            >
              <Menu size={23} />
            </button>
          </div>
        </div>
      </header>
      {menuOpen && (
        <div className="mobile-menu" role="dialog" aria-modal="true" aria-label="Menu di navigazione">
          <div className="mobile-menu__top">
            <BrandBlock />
            <button
              type="button"
              className="menu-trigger"
              onClick={() => setMenuOpen(false)}
              aria-label="Chiudi il menu di navigazione"
              autoFocus
            >
              <X size={24} />
            </button>
          </div>
          <nav className="mobile-menu__nav" aria-label="Navigazione mobile">
            {navigation.map((item, index) => (
              <Link key={item.label} href={item.href} onClick={() => setMenuOpen(false)}>
                <span>0{index + 1}</span>
                {item.label}
                <ArrowRight size={18} aria-hidden="true" />
              </Link>
            ))}
          </nav>
          <div className="mobile-menu__contact">
            <p>Per informazioni o appuntamenti</p>
            <a href={business.phoneHref}>{business.phoneDisplay}</a>
          </div>
        </div>
      )}
    </>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="site-footer__main">
        <div>
          <BrandBlock light />
          <p className="site-footer__summary">
            Chirurgia generale e colonproctologia con un approccio professionale, attento e orientato alla persona.
          </p>
        </div>
        <div className="site-footer__contact">
          <Eyebrow>Contatti</Eyebrow>
          <a href={business.phoneHref}>{business.phoneDisplay}</a>
          <a href={business.directionsUrl} target="_blank" rel="noreferrer">
            {business.addressShort}
          </a>
        </div>
        <div className="site-footer__links">
          <Eyebrow>Informazioni</Eyebrow>
          <Link href="/contatti">Contatti</Link>
          <a href={business.mapsListingUrl} target="_blank" rel="noreferrer">
            Google Maps
          </a>
          <Link href="/privacy">Privacy Policy</Link>
          <Link href="/cookie-policy">Cookie Policy</Link>
        </div>
      </div>
      <div className="site-footer__bottom">
        <span>© {new Date().getFullYear()} {business.businessName}</span>
        <span>Le informazioni cliniche non vengono raccolte tramite questo sito.</span>
      </div>
    </footer>
  );
}

export function MobileActionBar() {
  return (
    <nav className="mobile-action-bar" aria-label="Azioni rapide">
      <a href={business.phoneHref}>
        <Phone size={17} aria-hidden="true" />
        Chiama
      </a>
      <a href={business.directionsUrl} target="_blank" rel="noreferrer">
        <MapPin size={17} aria-hidden="true" />
        Indicazioni
      </a>
      <a href={business.phoneHref}>
        <CalendarDays size={17} aria-hidden="true" />
        Prenota
      </a>
    </nav>
  );
}

export function PageLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="site-shell">
      <a className="skip-link" href="#contenuto">
        Vai al contenuto
      </a>
      <SiteHeader />
      <main id="contenuto">{children}</main>
      <SiteFooter />
      <MobileActionBar />
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  lead,
  caption,
}: {
  eyebrow: string;
  title: string;
  lead: string;
  caption: string;
}) {
  return (
    <section className="page-hero">
      <div className="page-hero__inner">
        <div className="page-hero__meta">
          <span className="page-hero__line" aria-hidden="true" />
          <Eyebrow>{eyebrow}</Eyebrow>
        </div>
        <h1>{title}</h1>
        <p>{lead}</p>
        <small>{caption}</small>
      </div>
    </section>
  );
}

export function Gallery({ compact = false }: { compact?: boolean }) {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const selected = selectedIndex === null ? undefined : galleryItems[selectedIndex];

  useEffect(() => {
    if (!selected) return;
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedIndex(null);
      if (event.key === "ArrowRight") setSelectedIndex((current) => (current === null ? 0 : (current + 1) % galleryItems.length));
      if (event.key === "ArrowLeft") setSelectedIndex((current) => (current === null ? 0 : (current - 1 + galleryItems.length) % galleryItems.length));
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selected]);

  if (!galleryItems.length) {
    return (
      <div className={`gallery-pending ${compact ? "gallery-pending--compact" : ""}`}>
        <span className="gallery-pending__line" aria-hidden="true" />
        <div>
          <Eyebrow>Galleria dello studio</Eyebrow>
          <h3>Fotografie originali in aggiornamento</h3>
          <p>
            Questa sezione è predisposta per accogliere esclusivamente immagini autentiche e autorizzate dello studio.
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className={`gallery-grid ${compact ? "gallery-grid--compact" : ""}`} aria-label="Galleria fotografica dello studio">
        {galleryItems.map((image: GalleryItem, index) => (
          <button
            type="button"
            key={image.src}
            className="gallery-grid__item"
            onClick={() => setSelectedIndex(index)}
            aria-label={`Apri ${image.alt}`}
          >
            <img src={image.src} alt={image.alt} loading="lazy" />
            <span>Apri immagine</span>
          </button>
        ))}
      </div>
      {selected && selectedIndex !== null && (
        <div className="gallery-lightbox" role="dialog" aria-modal="true" aria-label={selected.alt}>
          <button
            type="button"
            className="gallery-lightbox__close"
            onClick={() => setSelectedIndex(null)}
            aria-label="Chiudi immagine"
            autoFocus
          >
            <X size={25} />
          </button>
          <button
            type="button"
            className="gallery-lightbox__move gallery-lightbox__move--previous"
            onClick={() => setSelectedIndex((selectedIndex - 1 + galleryItems.length) % galleryItems.length)}
            aria-label="Immagine precedente"
          >
            <ChevronLeft />
          </button>
          <figure>
            <img src={selected.src} alt={selected.alt} />
            {selected.caption && <figcaption>{selected.caption}</figcaption>}
          </figure>
          <button
            type="button"
            className="gallery-lightbox__move gallery-lightbox__move--next"
            onClick={() => setSelectedIndex((selectedIndex + 1) % galleryItems.length)}
            aria-label="Immagine successiva"
          >
            <ChevronRight />
          </button>
        </div>
      )}
    </>
  );
}

